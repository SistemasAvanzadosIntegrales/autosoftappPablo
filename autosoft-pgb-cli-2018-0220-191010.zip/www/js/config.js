var ruta_generica = "http://172.16.1.30:8000";
//var ruta_generica = "http://autosoft2.avansys.com.mx";

