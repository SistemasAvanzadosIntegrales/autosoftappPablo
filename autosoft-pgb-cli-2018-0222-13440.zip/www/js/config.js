//var ruta_generica = "http://localhost:8000";
var ruta_generica = "http://autosoft2.avansys.com.mx";

/**
 *  @author   : Pablo Diaz
 *  @Contact  : pablo_diaz@avansys.com.mx
 *  @date     : 25/01/2018
 *  @function : muestra
 **/
function muestra(nombre){
   $('.'+nombre).toggle();
}
