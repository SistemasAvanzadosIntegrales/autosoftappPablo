var ruta_generica = "http://172.16.1.30:8000";
